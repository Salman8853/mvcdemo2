/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.thar.service.impl;

import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thar.dtob.Employee;
import com.thar.repository.EmployeeRepository;
import com.thar.service.EmployeeService;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
public class EmployeesServiceImpl implements  EmployeeService{
     private static final Logger logger = LoggerFactory.getLogger(EmployeesServiceImpl.class);  
     @Autowired
     EmployeeRepository employeeRepository;
    
    public EmployeesServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }
     
     
    @Override
    public Employee saveEmp(Employee ee)
    { 
         return   employeeRepository.save(ee);
        
     }   
        
//    {  
 //       String res="";
//       try{
//            JSONObject jsonobj=new JSONObject();
//        Employee emp=    employeeRepository.getById(ee.getId());
//             if(emp!=null && emp.getId()>0)
//             {
//               emp.setId(ee.getId());
//               emp.setName(ee.getName());
//               emp.setRole(ee.getRole());
//              Employee empupdate= employeeRepository.save(emp);
//              if(empupdate!=null && empupdate.getId()>0)
//              {
//                jsonobj.put("responsecode", 200);
//	        jsonobj.put("message", "Record save succesfully");
//	        jsonobj.put("timestamp", new Date());
//                ObjectMapper obj=new ObjectMapper();
//                String containt=obj.writeValueAsString(empupdate);
//                jsonobj.put("data", new JSONObject(containt));   
//              }else
//              {
//              jsonobj.put("responsecode", 404);
//	      jsonobj.put("message", "Record Not updated");
//	      jsonobj.put("timestamp", new Date());
//              }
//             }else
//             {
//             Employee empsave=   employeeRepository.save(ee);
//               if(empsave!=null && empsave.getId()>0)
//               {
//                jsonobj.put("responsecode", 200);
//	        jsonobj.put("message", "Record save succesfully");
//	        jsonobj.put("timestamp", new Date());
//                ObjectMapper obj=new ObjectMapper();
//                String containt=obj.writeValueAsString(empsave);
//                jsonobj.put("data", new JSONObject(containt));  
//               }else
//               {
//               jsonobj.put("responsecode", 404);
//	       jsonobj.put("message", "Record Not saved");
//	       jsonobj.put("timestamp", new Date());
//               }
//             }
//           res=jsonobj.toString();
//           }catch(Exception ex)
//           {
//             ex.printStackTrace();
//             logger.error("Exception occured", ex);
//           }
//       return res;
 //    }
     @Override
     public Employee getEmpByid( Long id)
     {
   
        Employee emp=   employeeRepository.getById(id);
       return emp;
     
     }
      public List<Employee> getAllEmp()
      {
         return  employeeRepository.findAll();
      }
}
