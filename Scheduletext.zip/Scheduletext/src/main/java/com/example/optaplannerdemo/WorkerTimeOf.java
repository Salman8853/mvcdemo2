/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.optaplannerdemo;

import java.util.Date;

/**
 *
 * @author m.salman
 */
public class WorkerTimeOf {
    private Date todate;
   private Date fromdate;
   
    public Date getTodate() {
        return todate;
    }

    public void setTodate(Date todate) {
        this.todate = todate;
    }

    public Date getFromdate() {
        return fromdate;
    }

    public void setFromdate(Date fromdate) {
        this.fromdate = fromdate;
    }
   
}
