/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.optaplannerdemo;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class Driver {
  private String name;
  private String driverCode;
  private String globlerideCode;
  private Integer noOfBaggage;
  private Integer noOfPassengers;

    public Driver() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getGloblerideCode() {
        return globlerideCode;
    }

    public void setGloblerideCode(String globlerideCode) {
        this.globlerideCode = globlerideCode;
    }

    public Integer getNoOfBaggage() {
        return noOfBaggage;
    }

    public void setNoOfBaggage(Integer noOfBaggage) {
        this.noOfBaggage = noOfBaggage;
    }

    public Integer getNoOfPassengers() {
        return noOfPassengers;
    }

    public void setNoOfPassengers(Integer noOfPassengers) {
        this.noOfPassengers = noOfPassengers;
    }
  
}
