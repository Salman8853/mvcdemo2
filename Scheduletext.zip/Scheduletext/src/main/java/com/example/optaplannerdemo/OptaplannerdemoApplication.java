package com.example.optaplannerdemo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javassist.bytecode.stackmap.BasicBlock;
import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;

//@SpringBootApplication
public class OptaplannerdemoApplication {

	public static void main(String[] args) {
            try{
		//SpringApplication.run(OptaplannerdemoApplication.class, args);
               BookingAssignment unsolvedSchedule = new BookingAssignment();

            Booking ss=new Booking("aaaa", "bbbb", "ssss", "cccc",  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-04 08:00:00"), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-04 10:00:00"));
//            List<Schedule> slst=new ArrayList<Schedule>();
//            slst.add(ss);
            unsolvedSchedule.setScheduleList(ss);
             
             List<Driver> wlst=new ArrayList<Driver>();
              
             
              
               Driver w=new Driver();
               w.setWorkerCode("w111");
             List<String> skillList=new ArrayList<String>(); 
                  skillList.add("zzzz");
                  skillList.add("ssss");
                  w.setSkillList(skillList);
           List<String> certiList=new ArrayList<String>(); 
                  certiList.add("cccc");
                  certiList.add("yyyy");
                  w.setCertificationList(certiList);
 List<WorkerTimeOf> tomeofList=new ArrayList<WorkerTimeOf>(); 
            WorkerTimeOf timeof=new WorkerTimeOf();
              timeof.setFromdate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-04 08:00:00"));
              timeof.setTodate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-04 10:00:00"));
              tomeofList.add(timeof);
              w.setWorkertimeof(tomeofList);
              wlst.add(w);
              
             
             
             
            Driver   w1=new Driver();
               w1.setWorkerCode("w222");
           List<String>  skillList1=new ArrayList<String>(); 
                  skillList1.add("zzzz");
                  skillList1.add("ssss");
                  w1.setSkillList(skillList1);
          List<String> certiList1=new ArrayList<String>(); 
                  certiList1.add("dddd");
                  certiList1.add("cccc");
                  w1.setCertificationList(certiList1);
 List<WorkerTimeOf> tomeofList1=new ArrayList<WorkerTimeOf>(); 
          WorkerTimeOf   timeof1=new WorkerTimeOf();
              timeof1.setFromdate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-05 08:00:00"));
              timeof1.setTodate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2019-04-05 10:00:00"));
              tomeofList1.add(timeof1);
              w1.setWorkertimeof(tomeofList1);
              wlst.add(w1);
              
              
             unsolvedSchedule.setWorkerList(wlst);
        SolverFactory<BookingAssignment> solverFactory = SolverFactory.createFromXmlResource("com/example/optaplannerdemo/ScheduleSolverConfiguration.xml");
        Solver<BookingAssignment> solver = solverFactory.buildSolver();
        BookingAssignment solvedCourseSchedule = solver.solve(unsolvedSchedule);

// SolverFactory<CourseSchedule> solverFactory = SolverFactory.createFromXmlResource("com/example/optaplannerdemo/courseScheduleSolverConfigDrools.xml");
//        Solver<CourseSchedule> solver = solverFactory.buildSolver();
//        CourseSchedule solvedCourseSchedule = solver.solve(unsolvedCourseSchedule);

    //    solvedCourseSchedule.printCourseSchedule();
            System.out.println(">>>"+solvedCourseSchedule.toString());
            }catch(Exception ex){
            ex.printStackTrace();
        
        }
  }
}
   

