/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.optaplannerdemo;

import java.util.Date;
import org.optaplanner.core.api.domain.entity.PlanningEntity;
import org.optaplanner.core.api.domain.variable.PlanningVariable;

/**
 *
 * @author m.salman
 */
@PlanningEntity
public class Booking {

  private String rideCode;
  private Integer noofPassanger;
  private Integer noofBaggage;
  private String  globalrideCode;
  private Driver driver;
  
   
    
    
    
    
    
    
    
//    public Booking() {
//    }
//  
//   private String scheduleRequestCode;
//   private String scheduleRequestAssignmentCode;
//   private String skillCode;
//   private String certificationCode;
//   private Date todate;
//   private Date fromdate;
//   private Driver worker;
//
//    public String getScheduleRequestCode() {
//        return scheduleRequestCode;
//    }
//
//    public Booking(String scheduleRequestCode, String scheduleRequestAssignmentCode, String skillCode, String certificationCode, Date fromdate, Date todate) {
//        this.scheduleRequestCode = scheduleRequestCode;
//        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
//        this.skillCode = skillCode;
//        this.certificationCode = certificationCode;
//        this.todate = todate;
//        this.fromdate = fromdate;
//    }
//
//    public void setScheduleRequestCode(String scheduleRequestCode) {
//        this.scheduleRequestCode = scheduleRequestCode;
//    }
//
//    public String getScheduleRequestAssignmentCode() {
//        return scheduleRequestAssignmentCode;
//    }
//
//    public void setScheduleRequestAssignmentCode(String scheduleRequestAssignmentCode) {
//        this.scheduleRequestAssignmentCode = scheduleRequestAssignmentCode;
//    }
//
//    public String getSkillCode() {
//        return skillCode;
//    }
//
//    public void setSkillCode(String skillCode) {
//        this.skillCode = skillCode;
//    }
//
//    public String getCertificationCode() {
//        return certificationCode;
//    }
//
//    public void setCertificationCode(String certificationCode) {
//        this.certificationCode = certificationCode;
//    }
//
//    public Date getTodate() {
//        return todate;
//    }
//
//    public void setTodate(Date todate) {
//        this.todate = todate;
//    }
//
//    public Date getFromdate() {
//        return fromdate;
//    }
//
//    public void setFromdate(Date fromdate) {
//        this.fromdate = fromdate;
//    }
//     @PlanningVariable(valueRangeProviderRefs = {"worker"},nullable = true)
//    public Driver getWorker() {
//        return worker;
//    }
//
//    public void setWorker(Driver worker) {
//        this.worker = worker;
//    }

    public String getRideCode() {
        return rideCode;
    }

    public void setRideCode(String rideCode) {
        this.rideCode = rideCode;
    }

    public Integer getNoofPassanger() {
        return noofPassanger;
    }

    public void setNoofPassanger(Integer noofPassanger) {
        this.noofPassanger = noofPassanger;
    }

    public Integer getNoofBaggage() {
        return noofBaggage;
    }

    public void setNoofBaggage(Integer noofBaggage) {
        this.noofBaggage = noofBaggage;
    }

    public String getGlobalrideCode() {
        return globalrideCode;
    }

    public void setGlobalrideCode(String globalrideCode) {
        this.globalrideCode = globalrideCode;
    }
   @PlanningVariable(valueRangeProviderRefs = {"drivers"},nullable = true)
    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }
   
}
