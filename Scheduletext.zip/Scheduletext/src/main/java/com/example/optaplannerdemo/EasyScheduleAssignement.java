/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.optaplannerdemo;

import java.util.List;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.core.impl.score.director.easy.EasyScoreCalculator;

/**
 *
 * @author m.salman
 */
public class EasyScheduleAssignement implements EasyScoreCalculator<BookingAssignment>{
      @Override
      public HardSoftScore calculateScore(BookingAssignment schedulesassignement,int i)
      {
            int hardScore = 0;
            int softScore = 0; 
            boolean ismatch=false;
//         for(Booking ss:schedulesassignement.getScheduleList())   
//         {  
            Booking ss =schedulesassignement.getScheduleList();
             if(ss.getWorker()!=null)
            {
                
            
             
             for(Driver worker:schedulesassignement.getWorkerList()) 
             {  String assignworkerCode="";
//                 if(assignworkerCode.equals(worker.getWorkerCode()))
//                 {
//                    // hardScore+=-1;
//                 }else
//                 {
//                if(worker.getWorkertimeof()!=null && worker.getWorkertimeof().size()>0 )
//                {    Boolean timeofmatch=false;
//                   for(WorkerTimeOf wt:worker.getWorkertimeof())
//                   {
//                       if(ss.getFromdate().equals(wt.getFromdate())&& ss.getTodate().equals(wt.getTodate()))
//                       {
//                            timeofmatch=true;
//                            break;
//                       }
//                   }
//                     if(timeofmatch)
//                     {
//                         hardScore+=-1;
//                       continue;
//                     }
//                     
//                }
                




if(worker.getWorkertimeof()!=null && worker.getWorkertimeof().size()>0 )
                {    Boolean timeofmatch=false;
                   for(WorkerTimeOf wt:worker.getWorkertimeof())
                   {
                       if(ss.getFromdate().equals(wt.getFromdate())&& ss.getTodate().equals(wt.getTodate()))
                       {
                            timeofmatch=true;
                            break;
                       }
                   }
                     if(timeofmatch)
                     {
                        // hardScore+=-1;
                       continue;
                     }
                     
                }
                
                
                
               if(ss.getSkillCode()!=null)
               { Boolean skillmatch=false;
                  if(worker.getSkillList()!=null && worker.getSkillList().size()>0 )
                {      
                    List<String>skillList=worker.getSkillList();
                    if(skillList.contains(ss.getSkillCode()))
                    {
                        skillmatch=true;   
                    }else
                    {
                       // hardScore+=-1;
                       continue;
                    }  
                }
                  else
                  {
                       continue;
                  }
               }
               
               
               
               
                  if(ss.getCertificationCode()!=null)
               { Boolean certificatematch=false;
                  if(worker.getCertificationList()!=null && worker.getCertificationList().size()>0 )
                {      
                    List<String>certificationList=worker.getCertificationList();
                    if(certificationList.contains(ss.getCertificationCode()))
                    {
                        certificatematch=true;   
                    }else
                    {
                        //hardScore+=-1;
                       continue;
                    }  
                }
                  else
                  {
                       continue;
                  }
               }
                  
               ss.setWorker(worker);
               softScore--;
              ismatch=true;
               assignworkerCode=worker.getWorkerCode();
          // }
             }
            }else
            {
             hardScore+=-1;
            }
             
             if(!ismatch)
            {
              hardScore=-1*schedulesassignement.getWorkerList().size();
            }
             
        // }
         return HardSoftScore.valueOfInitialized(hardScore, softScore); 
      }
    
    
}