/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.optaplannerdemo;

import java.util.List;
import org.optaplanner.core.api.domain.solution.PlanningEntityCollectionProperty;
import org.optaplanner.core.api.domain.solution.PlanningEntityProperty;
import org.optaplanner.core.api.domain.solution.PlanningScore;
import org.optaplanner.core.api.domain.solution.PlanningSolution;
import org.optaplanner.core.api.domain.solution.drools.ProblemFactCollectionProperty;
import org.optaplanner.core.api.domain.valuerange.ValueRangeProvider;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;

/**
 *
 * @author m.salman
 */
@PlanningSolution
public class BookingAssignment {
    private List<Driver>workerList;
    private Booking scheduleList;
    private HardSoftScore score;

    public BookingAssignment() {
    }

    public BookingAssignment(List<Driver> workerList, Booking scheduleList) {
        this.workerList = workerList;
        this.scheduleList = scheduleList;
    }
    @ValueRangeProvider(id = "worker")
     @ProblemFactCollectionProperty
    public List<Driver> getWorkerList() {
        return workerList;
    }

    public void setWorkerList(List<Driver> workerList) {
        this.workerList = workerList;
    }
     
    
    
      @PlanningScore
    public HardSoftScore getScore() {
        return score;
    }
@PlanningEntityProperty
    public Booking getScheduleList() {
        return scheduleList;
    }

    public void setScheduleList(Booking scheduleList) {
        this.scheduleList = scheduleList;
    }

    public void setScore(HardSoftScore score) {
        this.score = score;
    }
    
    
}
